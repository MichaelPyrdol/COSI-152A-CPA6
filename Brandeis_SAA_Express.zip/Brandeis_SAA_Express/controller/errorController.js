const httpStatus=require("http-status-codes");
exports.pageNotFoundError=(req,res)=>{
  let errorCode = httpStatus.NOT_FOUND;
  res.status(errorCode);
  res.send(`${errorCode} | NOT FOUND`);
};
exports.internalServerError=(error,req,res,next)=>{
  let errorCode=httpStatus.INTERNAL_SERVER_ERROR;
  console.log(`ERROR occurred: ${error.stack}`);
  res.status(errorCode);
  res.send(`${errorCode} | Oops! Something happened.`);
};